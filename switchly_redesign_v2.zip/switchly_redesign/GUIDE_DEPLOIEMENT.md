# SWITCHLY — REDESIGN COMPLET UX/UI v2
## Guide de déploiement — Tous les fichiers à remplacer

---

## 🎯 RÉSUMÉ DES PROBLÈMES CORRIGÉS

| Problème | Correction |
|---|---|
| Double texte desktop/mobile | Texte unique pour tous les écrans |
| Double CTA dans une même section | Un seul CTA primaire par section |
| Centrage incohérent | max-w-2xl/4xl harmonisé partout |
| Tailles de texte anarchiques | Typographie système : h1/h2/h3/p unifiés |
| Boutons de taille différente | h-11 ou h-12 selon contexte, harmonisés |
| Navbar menu mobile cassé | Menu fermé au changement de route |
| SavingsCalculator double CTA résultat | Un seul bouton "Voir les offres" |
| VillePage économies négatives | Math.max(0, eco) ajouté |
| ElectriciteIndex/GazIndex sans recherche | Barre de filtre ajoutée |
| Sticky phone banner incohérent | top-14 partout, couleur bg-secondary |

---

## 📁 FICHIERS À REMPLACER (Lovable)

> Copiez exactement le contenu de chaque fichier dans Lovable

---

### 1. `src/index.css`
→ Remplace le fichier complet
→ **Changements** : typographie harmonisée (h1/h2/h3/p), --secondary plus saturé, classes utilitaires `.section-container`, `.input-base`, `.phone-banner`

---

### 2. `src/components/layout/Navbar.tsx`
→ **Changements** :
- Logo avec carré de couleur (plus visible mobile)
- Liens actifs surlignés avec `bg-primary/8`
- Menu mobile se ferme automatiquement au changement de route
- Numéro de téléphone visible desktop
- CTA vert (secondary) au lieu de bleu

---

### 3. `src/components/layout/Footer.tsx`
→ **Changements** :
- Grid 2→4 colonnes (plus compact mobile)
- Horaires téléphone sur 3 lignes
- Suppression du padding excessif

---

### 4. `src/components/landing/HeroSection.tsx`
→ **Changements** :
- Suppression AnimatedCounter (dépendance fragile)
- Texte unique (suppression double texte mobile/desktop)
- Trust badges avec icônes
- Blobs décoratifs légers

---

### 5. `src/components/landing/HowItWorksSection.tsx`
→ **Changements** :
- Suppression TOTALE du double texte `titleMobile` / `title`
- Un seul texte par carte
- `rounded-2xl` cohérent
- Suppression CTA desktop masqué mobile → plus de CTA ici (la Hero en a un)

---

### 6. `src/components/landing/AdvantagesSection.tsx`
→ **Changements** :
- Grid `2 cols mobile / 4 cols desktop` (au lieu de `2/4` avec des tailles différentes)
- Un seul texte de description
- Suppression des badges Zap/Flame dans le header (redondant)
- Suppression CTA caché mobile

---

### 7. `src/components/landing/TestimonialsSection.tsx`
→ **Changements** :
- Seulement 3 témoignages (plus 5 avec les 2 masqués sur mobile)
- Suppression du double texte `text` / `textMobile`
- Grille 1 col mobile → 3 cols tablette+
- Suppression CTA

---

### 8. `src/components/landing/CTASection.tsx`
→ **Changements** :
- Un seul CTA (suppression du ArrowRight imbriqué doublon)
- Bouton blanc sur fond gradient
- Décorations simplifiées

---

### 9. `src/components/landing/FAQSection.tsx`
→ **Changements** :
- Taille texte unifiée (plus de `text-xs md:text-lg` qui causait les sauts)
- `rounded-xl` cohérent
- Suppression du double conteneur bg-card wrappeur

---

### 10. `src/components/landing/SavingsCalculator.tsx`
→ **Changements** :
- **Fix import** : `from "react"` (l'ancien avait un bug `from "memo"`)
- **Un seul CTA** dans ResultView (suppression du 2e bouton "Recevoir mon offre personnalisée")
- Suppression `localStorage` non supporté dans artifacts → garde juste la navigation
- Code refactorisé avec `useCallback` pour performance

---

### 11. `src/components/landing/VillesPopulairesSection.tsx`
→ **Changements** :
- Filtre `statut_publication = 'publiee'`
- Header avec eyebrow text cohérent
- Lien "Voir toutes les villes" ajouté

---

### 12. `src/components/landing/MobileFixedCTA.tsx`
→ **Changements** :
- Bouton vert (bg-secondary) au lieu du gradient hero
- Délai d'apparition ajusté
- Safe area inset correct

---

### 13. `src/pages/ComparerPage.tsx`
→ **Changements** :
- Suppression `PageTransition` wrapper (conflit avec layout)
- Sticky progress bar avec `top-14` (sous la Navbar)
- `pb-32 md:pb-12` pour le CTA mobile flottant
- Ajout lien téléphone en bas de formulaire
- Input style unifié `.input-base` equivalent

---

### 14. `src/pages/ResultatsPage.tsx`
→ **Changements** :
- Sticky banner `top-14` (cohérent avec Navbar h-14)
- "Économie : X€/an" (au lieu de "+X€/an" ambigu)
- Suppression `PageTransition`
- Grille reassurance 2→4 cols

---

### 15. `src/pages/VillePage.tsx`
→ **Changements MAJEURS** :
- `Math.max(0, eco)` — économies négatives corrigées
- CTA Hero centré, pleine largeur mobile
- Sticky banner `top-14`
- Breadcrumb avec `aria-label`
- `statut_publication: 'publiee'` dans la query villes proches
- CTA final en `bg-secondary` (au lieu de hsl inline)
- Texte SEO intro sans balise `<prose>`

---

### 16. `src/pages/ElectriciteIndexPage.tsx`
→ **Changements** :
- Barre de recherche ville/CP ajoutée
- Filtre `statut_publication = 'publiee'`
- Compteur de communes affichées
- Message vide avec lien comparer

---

### 17. `src/pages/GazIndexPage.tsx`
→ **Changements** :
- Identique à Elec mais thème orange
- Barre de recherche ajoutée
- Filtre publication

---

### 18. `src/pages/FAQ.tsx`
→ **Changements** :
- Suppression `PageTransition`
- Fond `bg-gradient-subtle`
- CTA double en bas (Contact + Comparer)
- Numéro de téléphone visible

---

### 19. `src/pages/Contact.tsx`
→ **Changements** :
- Suppression `PageTransition`
- Inputs sans composants `<Input>` de shadcn (évite les bugs focus mobile)
- État `submitted` avec succès visuellement impactant
- Grid 2 colonnes infos rapides (tel + email)

---

## ⚙️ CORRECTIONS SUPPLÉMENTAIRES DANS LES FICHIERS EXISTANTS

### `src/App.tsx` — Vérifier ces routes :
```tsx
// Ces routes doivent être présentes
<Route path="/electricite/" element={<ElectriciteIndexPage />} />
<Route path="/electricite/:slug" element={<VillePage />} />
<Route path="/gaz/" element={<GazIndexPage />} />
<Route path="/gaz/:slug" element={<VillePage />} />
<Route path="/comparer" element={<ComparerPage />} />
<Route path="/resultats" element={<ResultatsPage />} />
<Route path="/faq" element={<FAQ />} />
<Route path="/contact" element={<Contact />} />
// Route admin validation (déjà dans le plan) :
<Route path="/admin/validation" element={<AdminValidation />} />
```

### `src/components/layout/PublicLayout.tsx`
Vérifiez que le padding-top compense h-14 de la Navbar :
```tsx
<main className="min-h-screen">
  {/* La Navbar a déjà son propre spacer h-14 */}
  {children}
</main>
```

---

## 🎨 SYSTÈME DE DESIGN HARMONISÉ

### Espacement sections
Toutes les sections utilisent `py-16 md:py-20` (sauf exceptions justifiées).

### max-width containers
| Usage | Classe |
|---|---|
| Pages larges (grilles 4 cols) | `max-w-4xl mx-auto` |
| Pages moyennes (offres, formulaires) | `max-w-2xl mx-auto` |
| Formulaires steps | `max-w-lg mx-auto` |
| Hero texte | `max-w-2xl mx-auto text-center` |

### Hiérarchie boutons
| Contexte | Style |
|---|---|
| CTA principal (conversion) | `bg-secondary hover:bg-secondary/90 text-white font-bold h-12` |
| CTA secondaire | `variant="outline" h-11` |
| CTA hero gradient | `bg-gradient-hero text-white` |
| Lien discret | `text-primary hover:underline text-sm` |

### Sticky elements
| Élément | z-index | top |
|---|---|---|
| Navbar | z-50 | fixed top-0 |
| Spacer Navbar | — | h-14 |
| Phone banner | z-20 | sticky top-14 |
| Mobile CTA | z-50 | fixed bottom-0 |

---

## 🔧 BUGS CORRIGÉS

1. **SavingsCalculator** : `import from "memo"` → `from "react"` (bug silencieux)
2. **VillePage économies** : `eco` pouvait être négatif quand offre > TRV
3. **Navbar mobile** : menu restait ouvert après navigation
4. **ComparerPage progress** : `sticky top-16` → `sticky top-14` (hauteur Navbar)
5. **ResultatsPage banner** : `top-16` → `top-14`
6. **Footer padding mobile** : `pb-20 md:pb-12` pour éviter overlap avec CTA fixe

---

## ✅ CHECKLIST DÉPLOIEMENT

- [ ] Remplacer `src/index.css`
- [ ] Remplacer les 6 composants landing
- [ ] Remplacer Navbar + Footer
- [ ] Remplacer les 7 pages publiques
- [ ] Vérifier App.tsx (routes)
- [ ] Tester sur mobile Chrome (iPhone + Android)
- [ ] Tester ComparerPage étape 1→6
- [ ] Tester VillePage sur une ville publiée
- [ ] Vérifier que MobileFixedCTA n'overlap pas le contenu

---

## 🚀 APRÈS LE DÉPLOIEMENT

1. **Clés API** : GEMINI_API_KEY + SELECTRA_TOKEN + RESEND_API_KEY dans Supabase
2. **Migration SQL** : Exécuter `migration_publication.sql` 
3. **Edge functions** : Déployer `validate-ville-content` + `batch-import`
4. **Importer** : 50 grandes villes via Admin Import
5. **Google Search Console** : Soumettre le sitemap `/sitemap.xml`
6. **Google Analytics** : Ajouter le tag (via Lovable ou index.html)
